﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface ITermRepository : IGenericRepository<Term>
    {
    }
}
