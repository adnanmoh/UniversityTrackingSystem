﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface ILevelRepository : IGenericRepository<Level>
    {
    }
}
