﻿namespace RestAPI.VMs
{
    public class SearchTeacher
    {
        public int? TeacherId { get; set; }

        public string? Name { get; set; } 
                    
        public string? Phone { get; set; } 
                     
        public string? Email { get; set; } 
                     
        public string? IdNumber { get; set; } 
                     
        public string? Password { get; set; } 
    }
}
