﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface INotificationTypeRepository : IGenericRepository<NotificationType>
    {
    }
}
