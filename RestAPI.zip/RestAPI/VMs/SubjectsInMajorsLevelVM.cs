﻿namespace RestAPI.VMs
{
    public class SubjectsInMajorsLevelVM
    {
        public int MajorId { get; set; }

        public int SubjectId { get; set; }

        public int LevelId { get; set; }

        public int TermId { get; set; }
    }
}
