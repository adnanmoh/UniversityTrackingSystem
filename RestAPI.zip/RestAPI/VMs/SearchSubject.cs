﻿namespace RestAPI.VMs
{
    public class SearchSubject
    {
        public int? SubjectId { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public bool? Status { get; set; }
    }
}
