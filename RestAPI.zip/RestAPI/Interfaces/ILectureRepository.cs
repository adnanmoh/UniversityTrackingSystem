﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface ILectureRepository : IGenericRepository<Lecture>
    {
       
    }
}
