﻿namespace RestAPI.VMs
{
    public class TeachingVM
    {
       
        public int TeacherId { get; set; }
       
        public int GroupId { get; set; }

        public int SubjectId { get; set; }
       
        public int MajorId { get; set; }
       
        public int YearId { get; set; }
        
        public int TermId { get; set; }
    }
}
