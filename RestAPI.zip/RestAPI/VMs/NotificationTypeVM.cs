﻿namespace RestAPI.VMs
{
    public class NotificationTypeVM
    {
        public int NotificationTypeId { get; set; }
        public string Name { get; set; } = null!;
    }
}
