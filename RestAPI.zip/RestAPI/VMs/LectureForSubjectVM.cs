﻿namespace RestAPI.VMs
{
    public class LectureForSubjectVM
    {
        
        public int LectureId { get; set; }
        public int SubjectId { get; set; }
    }
}
