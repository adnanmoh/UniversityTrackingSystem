﻿namespace RestAPI.VMs
{
    public class YearVM
    {
       
       
        public int YearId { get; set; }
     
        public int Year1 { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool Status { get; set; }
    }
}
