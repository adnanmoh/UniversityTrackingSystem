﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface IMajorRepository : IGenericRepository<Major>
    {
       
    }
}
