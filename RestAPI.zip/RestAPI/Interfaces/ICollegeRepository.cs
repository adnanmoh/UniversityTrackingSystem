﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface ICollegeRepository : IGenericRepository<College>
    {
    }
}
