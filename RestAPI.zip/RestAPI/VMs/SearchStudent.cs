﻿namespace RestAPI.VMs
{
    public class SearchStudent
    {
        public int? StudentId { get; set; }

        public string? Name { get; set; }

        public string? Phone { get; set; }

        public string? IdNumber { get; set; }

        public string? Password { get; set; }

        public int? GroupId { get; set; }
    }
}
