﻿using RestAPI.Models;

namespace RestAPI.Interfaces
{
    public interface ISubjectRepository :  IGenericRepository<Subject>
    {
       
    }
}
