﻿namespace RestAPI.VMs
{
    public class CollegeVM
    {
        public int CollegeId { get; set; }
        public string Name { get; set; } = null!;
        public string Location { get; set; } = null!;
    }
}
