﻿namespace RestAPI.VMs
{
    public class TermVM
    {
        public int TermId { get; set; }
        public string Name { get; set; } = null!;
    }
}
