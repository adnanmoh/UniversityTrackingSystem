﻿using RestAPI.Models;
using RestAPI.VMs;

namespace RestAPI.Interfaces
{
    public interface IAssignmentSolutionRepository : IGenericRepository<AssignmentSolution>
    {
/*        Task<ICollection<AssignmentSolution>> GetAssignmentSolutionByStudentIDAndAssignmentSolutionID(int assignmentSolutionID , int studentID);
*/
    }
}
